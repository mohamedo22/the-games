﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ChatSocketApp
{
    public partial class ClientForm : Form
    {
        private Socket _clientSocket;
        private Thread _receiveThread;

        public ClientForm()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                // Connect to the server
                _clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                _clientSocket.Connect(IPAddress.Parse(txtIP.Text), int.Parse(txtPort.Text));

                // Start the receiving thread
                _receiveThread = new Thread(ReceiveMessages);
                _receiveThread.Start();

                // Update the UI
                lblStatus.Text = "Connected";
                lblStatus.ForeColor = System.Drawing.Color.Green;
                btnConnect.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                // Send the message to the server
                byte[] buffer = Encoding.ASCII.GetBytes(txtInput.Text);
                _clientSocket.Send(buffer);

                // Clear the input text box
                txtInput.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ReceiveMessages()
        {
            try
            {
                while (true)
                {
                    try
                    {
                        // Receive a message from the server
                        byte[] buffer = new byte[1024];
                        int bytesReceived = _clientSocket.Receive(buffer);
                        string message = Encoding.ASCII.GetString(buffer, 0, bytesReceived);

                        if (!string.IsNullOrEmpty(message))
                        {
                            // Update the UI
                            txtOutput.Invoke(new Action(() =>
                            {
                                txtOutput.AppendText(message + Environment.NewLine);
                            }));
                            message = "";
                        }                      
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        break;
                    }
                }

                // Close the socket and update the UI
                _clientSocket.Close();
                lblStatus.Invoke(new Action(() =>
                {
                    lblStatus.Text = "Disconnected";
                    lblStatus.ForeColor = System.Drawing.Color.Red;
                    btnConnect.Enabled = true;
                }));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Close the socket and stop the receiving thread
            _clientSocket.Close();
            _receiveThread.Abort();
        }
    }
}