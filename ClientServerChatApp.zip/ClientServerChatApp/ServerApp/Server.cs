﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace ChatServer
{
    class Server
    {
        static List<TcpClient> clients=new List<TcpClient>();

        static void Main(string[] args)
        {
            TcpListener listener = new TcpListener(IPAddress.Any, 8888);
            listener.Start();
            Console.WriteLine("Chat server started on port 8888");

            while (true)
            {
                // Wait for a client to connect
                TcpClient client = listener.AcceptTcpClient();

                Console.WriteLine("Client connected");

                // Start a new thread to handle the client
                Thread clientThread = new Thread(HandleClient);
                clientThread.Start(client);
                clients.Add(client);
            }
        }

        static void HandleClient(object obj)
        {
            TcpClient client = (TcpClient)obj;

            try
            {
                // Get the client stream
                NetworkStream stream = client.GetStream();

                // Send a welcome message to the client
                string welcomeMessage = "Welcome to the chat server!";
                byte[] welcomeBuffer = Encoding.ASCII.GetBytes(welcomeMessage);
                stream.Write(welcomeBuffer, 0, welcomeBuffer.Length);

                // Start a loop to handle messages from the client
                while (true)
                {
                    // Read the message from the client
                    byte[] buffer = new byte[1024];
                    int bytesReceived = stream.Read(buffer, 0, buffer.Length);
                    string message = Encoding.ASCII.GetString(buffer, 0, bytesReceived);

                    // Broadcast the message to all connected clients
                    BroadcastMessage(message);

                    //// Echo the message back to the client
                    //byte[] echoBuffer = Encoding.ASCII.GetBytes("You said: " + message);
                    //stream.Write(echoBuffer, 0, echoBuffer.Length);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Client disconnected: " + ex.Message);
            }
            finally
            {
                // Clean up the client resources
                client.Close();
            }
        }

        static void BroadcastMessage(string message)
        {
            // Send the message to all connected clients
            byte[] buffer = Encoding.ASCII.GetBytes(message);
            Console.WriteLine(message);

            foreach (TcpClient client in clients)
            {
                NetworkStream stream = client.GetStream();
                stream.Write(buffer, 0, buffer.Length);
            }
        }
    }
}