namespace game_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
        int le = 10;
        int score = 0;
        Random r = new Random();

        private void timer1_Tick(object sender, EventArgs e)
        {
            apple1.Top += 6;
            apple2.Top += 4;
            apple3.Top += 5;
            cloud.Left -= le;
            label1.BackColor = Color.White;
            label1.Text = "your score is  " + score;
            label2.Text = "";
            label3.Text = "";
            if (cloud.Left < -120) { cloud.Left = 680; }
            if (desh.Left < 0) { desh.Left = 2; }
            if (desh.Left > 550) { desh.Left = 540; }
            if (desh.Bounds.IntersectsWith(apple1.Bounds))
            {
                apple1.Top = -110;
                apple1.Left = r.Next(0, 250);
                score++;
            }
            if (desh.Bounds.IntersectsWith(apple2.Bounds))
            {
                apple2.Top = -110;
                apple2.Left = r.Next(250, 350);
                score++;
            }
            if (desh.Bounds.IntersectsWith(apple3.Bounds))
            {
                apple3.Top = -110;
                apple3.Left = r.Next(350, 500);
                score++;

            }
            if (pictureBox1.Bounds.IntersectsWith(apple1.Bounds) || pictureBox1.Bounds.IntersectsWith(apple2.Bounds) || pictureBox1.Bounds.IntersectsWith(apple3.Bounds))
            {
                timer1.Stop();
            }
            if (timer1.Enabled == false)
            {
                label2.BackColor = Color.Black;
                label2.ForeColor = Color.White;
                label2.Text = "GAME OVER YOUR SCORE IS  $   " + score + "  $ ";
                label3.Text = "press enter to start ";
                label3.BackColor = Color.White;
            }
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (timer1.Enabled == false)
            {
             
                if (e.KeyCode == Keys.Enter) { timer1.Start(); apple1.Top = -110; apple1.Left = r.Next(0, 250); apple2.Top = -110; apple2.Left = r.Next(250, 350); apple3.Top = -110; apple3.Left = r.Next(350, 500); score = 0; }
              
            }
            if (e.KeyCode == Keys.Left) { desh.Left -= le; }
            if (e.KeyCode == Keys.Right) { desh.Left += le; }
        }
    }
}