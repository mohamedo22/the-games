﻿namespace game_3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox1 = new PictureBox();
            desh = new PictureBox();
            apple1 = new PictureBox();
            apple2 = new PictureBox();
            label1 = new Label();
            cloud = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            apple3 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)desh).BeginInit();
            ((System.ComponentModel.ISupportInitialize)apple1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)apple2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)cloud).BeginInit();
            ((System.ComponentModel.ISupportInitialize)apple3).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, 396);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(719, 42);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // desh
            // 
            desh.Image = (Image)resources.GetObject("desh.Image");
            desh.Location = new Point(261, 361);
            desh.Name = "desh";
            desh.Size = new Size(154, 37);
            desh.SizeMode = PictureBoxSizeMode.StretchImage;
            desh.TabIndex = 1;
            desh.TabStop = false;
            // 
            // apple1
            // 
            apple1.Image = (Image)resources.GetObject("apple1.Image");
            apple1.Location = new Point(564, 24);
            apple1.Name = "apple1";
            apple1.Size = new Size(75, 44);
            apple1.SizeMode = PictureBoxSizeMode.StretchImage;
            apple1.TabIndex = 2;
            apple1.TabStop = false;
            // 
            // apple2
            // 
            apple2.Image = (Image)resources.GetObject("apple2.Image");
            apple2.Location = new Point(77, -102);
            apple2.Name = "apple2";
            apple2.Size = new Size(75, 44);
            apple2.SizeMode = PictureBoxSizeMode.StretchImage;
            apple2.TabIndex = 3;
            apple2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(-2, 0);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 4;
            label1.Text = "label1";
            // 
            // cloud
            // 
            cloud.Image = (Image)resources.GetObject("cloud.Image");
            cloud.Location = new Point(294, 0);
            cloud.Name = "cloud";
            cloud.Size = new Size(229, 35);
            cloud.SizeMode = PictureBoxSizeMode.StretchImage;
            cloud.TabIndex = 5;
            cloud.TabStop = false;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // apple3
            // 
            apple3.Image = (Image)resources.GetObject("apple3.Image");
            apple3.Location = new Point(294, -107);
            apple3.Name = "apple3";
            apple3.Size = new Size(75, 44);
            apple3.SizeMode = PictureBoxSizeMode.StretchImage;
            apple3.TabIndex = 6;
            apple3.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(261, 156);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 7;
            label2.Text = "label2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(275, 184);
            label3.Name = "label3";
            label3.Size = new Size(38, 15);
            label3.TabIndex = 8;
            label3.Text = "label3";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(720, 450);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(apple3);
            Controls.Add(cloud);
            Controls.Add(label1);
            Controls.Add(apple2);
            Controls.Add(apple1);
            Controls.Add(desh);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)desh).EndInit();
            ((System.ComponentModel.ISupportInitialize)apple1).EndInit();
            ((System.ComponentModel.ISupportInitialize)apple2).EndInit();
            ((System.ComponentModel.ISupportInitialize)cloud).EndInit();
            ((System.ComponentModel.ISupportInitialize)apple3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox desh;
        private PictureBox apple1;
        private PictureBox apple2;
        private Label label1;
        private PictureBox cloud;
        private System.Windows.Forms.Timer timer1;
        private PictureBox apple3;
        private Label label2;
        private Label label3;
    }
}