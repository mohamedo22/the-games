﻿namespace fla
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            bird = new PictureBox();
            Pipeup = new PictureBox();
            pipe = new PictureBox();
            pictureBox4 = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            pipeup2 = new PictureBox();
            pipe2 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)bird).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Pipeup).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pipe).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pipeup2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pipe2).BeginInit();
            SuspendLayout();
            // 
            // bird
            // 
            bird.Image = (Image)resources.GetObject("bird.Image");
            bird.Location = new Point(115, 99);
            bird.Name = "bird";
            bird.Size = new Size(58, 50);
            bird.SizeMode = PictureBoxSizeMode.Zoom;
            bird.TabIndex = 0;
            bird.TabStop = false;
            // 
            // Pipeup
            // 
            Pipeup.Image = (Image)resources.GetObject("Pipeup.Image");
            Pipeup.Location = new Point(329, -13);
            Pipeup.Name = "Pipeup";
            Pipeup.Size = new Size(58, 119);
            Pipeup.SizeMode = PictureBoxSizeMode.StretchImage;
            Pipeup.TabIndex = 1;
            Pipeup.TabStop = false;
            // 
            // pipe
            // 
            pipe.Image = (Image)resources.GetObject("pipe.Image");
            pipe.Location = new Point(409, 213);
            pipe.Name = "pipe";
            pipe.Size = new Size(58, 119);
            pipe.SizeMode = PictureBoxSizeMode.StretchImage;
            pipe.TabIndex = 2;
            pipe.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(-63, 328);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(766, 112);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 3;
            pictureBox4.TabStop = false;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // pipeup2
            // 
            pipeup2.Image = (Image)resources.GetObject("pipeup2.Image");
            pipeup2.Location = new Point(571, -3);
            pipeup2.Name = "pipeup2";
            pipeup2.Size = new Size(58, 119);
            pipeup2.SizeMode = PictureBoxSizeMode.StretchImage;
            pipeup2.TabIndex = 4;
            pipeup2.TabStop = false;
            // 
            // pipe2
            // 
            pipe2.Image = (Image)resources.GetObject("pipe2.Image");
            pipe2.Location = new Point(571, 247);
            pipe2.Name = "pipe2";
            pipe2.Size = new Size(58, 85);
            pipe2.SizeMode = PictureBoxSizeMode.StretchImage;
            pipe2.TabIndex = 5;
            pipe2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 6;
            label1.Text = "label1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(329, 134);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 7;
            label2.Text = "label2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(329, 173);
            label3.Name = "label3";
            label3.Size = new Size(38, 15);
            label3.TabIndex = 8;
            label3.Text = "label3";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(706, 376);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pipe2);
            Controls.Add(pipeup2);
            Controls.Add(pictureBox4);
            Controls.Add(pipe);
            Controls.Add(Pipeup);
            Controls.Add(bird);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            KeyUp += Form1_KeyUp;
            ((System.ComponentModel.ISupportInitialize)bird).EndInit();
            ((System.ComponentModel.ISupportInitialize)Pipeup).EndInit();
            ((System.ComponentModel.ISupportInitialize)pipe).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pipeup2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pipe2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox bird;
        private PictureBox Pipeup;
        private PictureBox pipe;
        private PictureBox pictureBox4;
        private System.Windows.Forms.Timer timer1;
        private PictureBox pipeup2;
        private PictureBox pipe2;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}