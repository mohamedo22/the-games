namespace fla
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        int d = 15;
        int le = 5;
        Random r = new Random();
        int score = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            bird.Top += d;

            pipe.Left -= le;
            Pipeup.Left -= le;
            pipe2.Left -= le;
            pipeup2.Left -= le;
            label1.Text = ("your score is " + score);

            if (pipe.Left < 5)
            { pipe.Left = r.Next(400, 550); score++; }
            if (Pipeup.Left < 5)
            { Pipeup.Left = r.Next(500, 550); score++; }
            if (pipe2.Left < 5)
            { pipe2.Left = r.Next(560, 600); score++; }
            if (pipeup2.Left < 5)
            { pipeup2.Left = r.Next(580, 610); score++; }
            if (bird.Bounds.IntersectsWith(pipe.Bounds) || bird.Bounds.IntersectsWith(pipe2.Bounds) || bird.Bounds.IntersectsWith(Pipeup.Bounds) || bird.Bounds.IntersectsWith(pipeup2.Bounds) || bird.Bounds.IntersectsWith(pictureBox4.Bounds))
            {
                timer1.Stop();
                label2.Text = "GAME OVER YOUR SCORE IS $ " + score + " $";
                label2.BackColor = Color.Black;
                label2.ForeColor = Color.White;
                label3.BackColor = Color.White;
                label3.ForeColor = Color.Black;
                label3.Text = "  press enter to start the game";

            }

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (timer1.Enabled == false)

            {
                label3.Text = "press enter to start ";
                label3.BackColor = Color.White;
                label3.ForeColor = Color.Black;
                if (e.KeyCode == Keys.Enter)
                {
                    timer1.Start(); pipe.Left = r.Next(400, 550); Pipeup.Left = r.Next(500, 550); pipe2.Left = r.Next(560, 600); pipeup2.Left = r.Next(580, 610); bird.Top = 100;
                    label2.Text = "";
                    score = 0;
                    label3.Text = "";
                }

            }
            if (e.KeyCode == Keys.Space) { d -= 20; }
            if (bird.Top < 2) { bird.Top = 16; }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space) { d = 10; }
        }
    }
}