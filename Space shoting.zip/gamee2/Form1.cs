﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gamee2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random r= new Random();
        private void copyimg()
        {
            PictureBox p= new PictureBox();
            p.Size = f1.Size;
            p.SizeMode = f1.SizeMode;
            p.BackColor = f1.BackColor;
            p.Tag = "p";
            p.Image = Properties.Resources.bull;
            p.Top = air.Top - 30;
            p.Left= air.Left + 50;
            this.Controls.Add(p);
            p.BringToFront();
        }
        private void move()
        {
        foreach(Control c in this.Controls)
            {
                if(c is PictureBox &&  c.Tag=="p")
                {
                    c.Top -= 10;
                    if(c.Top<-112)
                    {
                        c.Top -= 10;
                    }
                    if (c.Top < 90)
                    {
                        this.Controls.Remove(c);
                    }
                    
                }
            }
        }
        private void res()
        {
            foreach(Control j in this.Controls)
            {
                foreach(Control i in this.Controls)
                {
                    if (j is PictureBox && j.Tag== "p")
                    {
                        if (i is PictureBox && i.Tag=="v")
                        {
                            if (j.Bounds.IntersectsWith(i.Bounds))
                            {
                                s++;
                                if (s >= 6)
                                {
                                    i.Top = -120;
                                    score++;
                                    s = 0;
                                }
                                   

                            }
                            
                        }
                    }
                }
            }
        }
        int s;
        PictureBox i;
        int score;

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = "YOUR SCORE IS  " + score;
            v1.Top += 9;
            v2.Top += 9;
            v3.Top += 9;
            v4.Top += 9;
            if(v1.Top > 500) { v1.Top = -112; v1.Left = r.Next(0, 250); }
            if(v2.Top > 500) { v2.Top = -112;v2.Left = r.Next(260, 350); }
            if(v3.Top > 500) { v3.Top = -112; v3.Left = r.Next(360, 750); }
            if (v4.Top > 500) { v4.Top = -112; v4.Left = r.Next(360, 750); }
            label2.Text = "";
            label3.Text = "";
            if (score > 20)
            {
                v1.Top += 11;
                v2.Top += 11;
                v3.Top += 11;
                v4.Top += 11;
            }
            if (score >40)
            {
                v1.Top += 13;
                v2.Top += 13;
                v3.Top +=13;
                v4.Top += 13;
            }
            if (score > 60)
            {
                v1.Top += 15;
                v2.Top += 15;
                v3.Top += 15;
                v4.Top += 15;
            }
            if(air.Bounds.IntersectsWith(v1.Bounds) || air.Bounds.IntersectsWith(v2.Bounds) || air.Bounds.IntersectsWith(v3.Bounds) || air.Bounds.IntersectsWith(v4.Bounds))
            {
                timer1.Stop();
                label2.Text = "GAME OVER";
                label3.Text = "PRESS ENTER TO START";
            }

            move();
            res();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (timer1.Enabled == false)
            {
                if (e.KeyCode == Keys.Enter) 
                {
                    timer1.Start();
                    v1.Top = -120;
                    v2.Top = -120;
                    v3.Top = -120;
                    v4.Top = -120;
                    score = 0;
                    air.Left = 462;
                    
                    
                }
            }
            if (e.KeyCode== Keys.Right)
            {
                air.Left += 30;
            }

            if (e.KeyCode == Keys.Left)
            {
                air.Left -= 30;
            }

            if (e.KeyCode== Keys.Space)
            {
                copyimg();
            }
        }
    }
}
