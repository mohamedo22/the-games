﻿namespace gamee2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.air = new System.Windows.Forms.PictureBox();
            this.f1 = new System.Windows.Forms.PictureBox();
            this.v3 = new System.Windows.Forms.PictureBox();
            this.v2 = new System.Windows.Forms.PictureBox();
            this.v1 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.v4 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.air)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.v3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.v2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.v1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.v4)).BeginInit();
            this.SuspendLayout();
            // 
            // air
            // 
            this.air.Image = global::gamee2.Properties.Resources.Picsart_23_03_07_12_32_54_319;
            this.air.Location = new System.Drawing.Point(462, 578);
            this.air.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.air.Name = "air";
            this.air.Size = new System.Drawing.Size(202, 95);
            this.air.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.air.TabIndex = 0;
            this.air.TabStop = false;
            // 
            // f1
            // 
            this.f1.Image = global::gamee2.Properties.Resources.bull;
            this.f1.Location = new System.Drawing.Point(540, 531);
            this.f1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.f1.Name = "f1";
            this.f1.Size = new System.Drawing.Size(50, 38);
            this.f1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.f1.TabIndex = 1;
            this.f1.TabStop = false;
            // 
            // v3
            // 
            this.v3.Image = global::gamee2.Properties.Resources.Picsart_23_03_07_12_35_30_911;
            this.v3.Location = new System.Drawing.Point(1030, 2);
            this.v3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.v3.Name = "v3";
            this.v3.Size = new System.Drawing.Size(78, 58);
            this.v3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.v3.TabIndex = 3;
            this.v3.TabStop = false;
            this.v3.Tag = "v";
            // 
            // v2
            // 
            this.v2.Image = global::gamee2.Properties.Resources.Picsart_23_03_07_12_35_30_911;
            this.v2.Location = new System.Drawing.Point(622, 2);
            this.v2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.v2.Name = "v2";
            this.v2.Size = new System.Drawing.Size(72, 58);
            this.v2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.v2.TabIndex = 4;
            this.v2.TabStop = false;
            this.v2.Tag = "v";
            // 
            // v1
            // 
            this.v1.Image = global::gamee2.Properties.Resources.Picsart_23_03_07_12_35_30_911;
            this.v1.Location = new System.Drawing.Point(210, -17);
            this.v1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.v1.Name = "v1";
            this.v1.Size = new System.Drawing.Size(78, 58);
            this.v1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.v1.TabIndex = 5;
            this.v1.TabStop = false;
            this.v1.Tag = "v";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::gamee2.Properties.Resources.stars23;
            this.pictureBox7.Location = new System.Drawing.Point(-9, 2);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(1210, 380);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::gamee2.Properties.Resources.stars23;
            this.pictureBox8.Location = new System.Drawing.Point(-9, 374);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(1210, 268);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 7;
            this.pictureBox8.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // v4
            // 
            this.v4.Image = global::gamee2.Properties.Resources.Picsart_23_03_07_12_35_30_911;
            this.v4.Location = new System.Drawing.Point(416, -17);
            this.v4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.v4.Name = "v4";
            this.v4.Size = new System.Drawing.Size(72, 58);
            this.v4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.v4.TabIndex = 8;
            this.v4.TabStop = false;
            this.v4.Tag = "v";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(58, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label2.Location = new System.Drawing.Point(406, 311);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(330, 58);
            this.label2.TabIndex = 10;
            this.label2.Text = "GAME - OVER";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Azure;
            this.label3.Location = new System.Drawing.Point(357, 387);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(216, 33);
            this.label3.TabIndex = 11;
            this.label3.Text = "GAME - OVER";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.v4);
            this.Controls.Add(this.v1);
            this.Controls.Add(this.v2);
            this.Controls.Add(this.v3);
            this.Controls.Add(this.air);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.f1);
            this.Controls.Add(this.pictureBox7);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.air)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.v3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.v2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.v1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.v4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox air;
        private System.Windows.Forms.PictureBox f1;
        private System.Windows.Forms.PictureBox v3;
        private System.Windows.Forms.PictureBox v2;
        private System.Windows.Forms.PictureBox v1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox v4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

